<?php
include('auth.php');
include('db.php');
redirectIfNotLoggedIn();

// Handle task deletion
if(isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM tasks WHERE id = $delete_id";
    $conn->query($sql);
}

// Handle task enable/disable
if(isset($_GET['toggle_id'])) {
    $toggle_id = $_GET['toggle_id'];
    $sql = "UPDATE tasks SET enabled = NOT enabled WHERE id = $toggle_id";
    $conn->query($sql);
}

// Handle task update
if(isset($_POST['update_id'])) {
    $update_id = $_POST['update_id'];
    $new_task_name = $_POST['new_task_name'];
    $new_due_date = $_POST['new_due_date'];
    $enabled = isset($_POST['enabled']) ? 1 : 0; // 1 for enabled, 0 for disabled

    $sql = "UPDATE tasks SET task_name='$new_task_name', due_date='$new_due_date', enabled=$enabled WHERE id=$update_id";
    $conn->query($sql);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['update_id'])) {
    $task_name = $_POST['task_name'];
    $due_date = $_POST['due_date'];

    $sql = "INSERT INTO tasks (task_name, due_date) VALUES ('$task_name', '$due_date')";
    $conn->query($sql);
}

$sql = "SELECT * FROM tasks";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task Reminder</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Task Reminder</h1>
        <div class="text-right mt-3">
    <a href="logout.php" class="btn btn-danger">Logout</a>
</div>
        <div class="row mt-4">
       
            <div class="col-md-6">
                <h2>Tasks:</h2>
                <ul class="list-group">
                    <?php while($row = $result->fetch_assoc()): ?>
                        <li class="list-group-item">
                            <?php echo $row['task_name']; ?> 
                            (Due: <?php echo $row['due_date']; ?>) 
                            <?php if($row['enabled'] == 1): ?>
                                <span class="badge badge-success">Enabled</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Disabled</span>
                            <?php endif; ?>
                            <a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm float-right">Delete</a>
                            <a href="#" class="btn btn-info btn-sm float-right mr-2" data-toggle="modal" data-target="#editModal<?php echo $row['id']; ?>">Edit</a>
                            <a href="?toggle_id=<?php echo $row['id']; ?>" class="btn btn-secondary btn-sm float-right mr-2">
                                <?php echo ($row['enabled'] == 1) ? 'Disable' : 'Enable'; ?>
                            </a>
                        </li>

                        <!-- Edit Modal -->
                        <div class="modal fade" id="editModal<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalLabel">Edit Task</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post">
                                            <input type="hidden" name="update_id" value="<?php echo $row['id']; ?>">
                                            <div class="form-group">
                                                <label for="new_task_name">New Task Name:</label>
                                                <input type="text" class="form-control" id="new_task_name" name="new_task_name" value="<?php echo $row['task_name']; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="new_due_date">New Due Date:</label>
                                                <input type="date" class="form-control" id="new_due_date" name="new_due_date" value="<?php echo $row['due_date']; ?>" required>
                                            </div>
                                            <div class="form-group form-check">
                                                <input type="checkbox" class="form-check-input" id="enabled" name="enabled" <?php echo ($row['enabled'] == 1) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="enabled">Enabled</label>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </ul>
            </div>

            <div class="col-md-6">
                <h2>Add Task:</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="task_name">Task Name:</label>
                        <input type="text" class="form-control" id="task_name" name="task_name" required>
                    </div>
                    <div class="form-group">
                        <label for="due_date">Due Date:</label>
                        <input type="date" class="form-control" id="due_date" name="due_date" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Task</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
