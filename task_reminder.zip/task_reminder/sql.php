CREATE DATABASE task_reminder;
USE task_reminder;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE,
    password VARCHAR(255)
);

CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    task_name VARCHAR(255),
    due_date DATE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

// paste in  phpmyadmin there is option sql

ALTER TABLE tasks
ADD COLUMN enabled BOOLEAN DEFAULT 1;